# DB 周りを import
#from main import db
import os
from flask import Flask, render_template , request , url_for , redirect
from flask_sqlalchemy import SQLAlchemy
import func_list

#print('テーブル削除スタート')
#User.query.delete()
#db.session.commit()
#print('テーブル削除完了')

#このファイルを指定実行した場合のみ初期化
if __name__ == '__main__':
    #既存DBファイルがある場合は削除
    omame_db_file_path = os.path.join(os.path.abspath('.') , 'omame.db')
    if os.path.exists(omame_db_file_path):
        print('存在')
        os.remove(omame_db_file_path)
    
    app = Flask(__name__)
    
    
    #データベース構築
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///omame.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
    
    db = SQLAlchemy(app)
    
    #テーブル定義
    #--テスト
    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        username = db.Column(db.String(80))
        test = db.Column(db.String(80))
    
        def __init__(self, username , test):
            self.username = username
            self.test = test
    
    #--料理と材料の組
    class Comb_cuisine_ingredient(db.Model):
        #キー
        cuisine_id = db.Column(db.Integer, primary_key=True)
        ingredient_id = db.Column(db.Integer, primary_key=True)
        
        #個数
        #ingredient_pieces = db.Column(db.Integer)
        ingredient_pieces = db.Column(db.String(100))
        
        #テスト
        #def testt(self):
            #print('OKOKOKOKOKOKOKOKOKOKOK')
    
        def __init__(self, cuisine_id , ingredient_id , ingredient_pieces):
            self.cuisine_id = cuisine_id
            self.ingredient_id = ingredient_id
            self.ingredient_pieces = ingredient_pieces
            
        #Comb_cuisine_ingredientテーブル、Cuisine_infoテーブル、Ingredient_infoテーブルにcuisine_listのデータを取り込む
        def import_cuisine_list_for_cuisine_and_ingredient_and_comb(cuisine_list):
            #キー用の連番
            cuisine_key = 1
            ingredient_key = 1
            
            #キー：材料名、値：ingredient_id  の辞書（各材料のキー値を保持するために以下で使用）
            ingredient_key_dict = {}
            
            for cuisine in cuisine_list:
                #Cuisine_infoレコード作成
                cuisine_info = Cuisine_info(cuisine_key
                                                , cuisine['cuisine_name']
                                                , cuisine['image']
                                                , cuisine['category']
                                                , cuisine['cooking_time']
                                                , cuisine['how_to_cook']
                                                
                                                , cuisine['nutrition']['calorie']
                                                , cuisine['nutrition']['salt']
                                                , cuisine['nutrition']['protein']
                                                , cuisine['nutrition']['lipid']
                                                , cuisine['nutrition']['carbohydrate']
                                                , cuisine['nutrition']['dietary_fiber']
                                                , cuisine['nutrition']['iron']
                                                , cuisine['nutrition']['calcium']
                                                )
                
                db.session.add(cuisine_info)
    
                #材料取得
                ingredients = cuisine['ingredients']
                
                for ingredient_nm , ingredient_amount in ingredients.items():
                    #まだ対象の材料に連番を付与していない場合は連番を付与して、辞書に登録し、連番を進める
                    if ingredient_nm not in ingredient_key_dict.keys():
                        #材料テーブルレコード作成
                        ingredient_info = Ingredient_info(ingredient_key , ingredient_nm , None , None)
                        db.session.add(ingredient_info)
                        
                        #戻り値（辞書）に登録
                        ingredient_key_dict[ingredient_nm] = ingredient_key
                        ingredient_key += 1
                    
                    #料理・材料テーブルレコード作成
                    #※ifがTrue、Falseでも対象材料が辞書に入っている状態になるので、辞書から連番取得
                    comb_cuisine_ingredient = Comb_cuisine_ingredient(cuisine_key , ingredient_key_dict[ingredient_nm] , ingredient_amount)
                    db.session.add(comb_cuisine_ingredient)
                    
                    cuisine_key += 1
                
            db.session.commit()
            
    #--料理
    class Cuisine_info(db.Model):
        #キー
        cuisine_id = db.Column(db.Integer, primary_key=True)
        
        #料理名
        cuisine_name = db.Column(db.String(100) , unique=True)
        #画像ファイル名（拡張子含む）
        image = db.Column(db.String(100))
        #カテゴリ
        category = db.Column(db.String(100))
        #調理時間
        cooking_time = db.Column(db.Integer)
        #作り方
        how_to_cook = db.Column(db.String(1000))
        
        #栄養
        #--カロリー
        calorie = db.Column(db.Integer)
        #--塩分
        salt = db.Column(db.Integer)
        #--タンパク質
        protein = db.Column(db.Integer)
        #--脂質
        lipid = db.Column(db.Integer)
        #--炭水化物
        carbohydrate = db.Column(db.Integer)
        #--食物繊維
        dietary_fiber = db.Column(db.Integer)
        #--鉄分
        iron = db.Column(db.Integer)
        #--カルシウム
        calcium = db.Column(db.Integer)
        
        def __init__(self
                        , cuisine_id 
                        , cuisine_name
                        , image
                        , category
                        , cooking_time
                        , how_to_cook
                        , calorie
                        , salt
                        , protein
                        , lipid
                        , carbohydrate
                        , dietary_fiber
                        , iron
                        , calcium
                        ):
                        
            self.cuisine_id = cuisine_id 
            self.cuisine_name = cuisine_name 
            self.image= image
            self.category= category
            self.cooking_time= cooking_time
            self.how_to_cook= how_to_cook
            self.calorie= calorie
            self.salt= salt
            self.protein= protein
            self.lipid= lipid
            self.carbohydrate= carbohydrate
            self.dietary_fiber= dietary_fiber
            self.iron= iron
            self.calcium= calcium
            
        #cuisin_list（関数「get_cuisine_list」の戻り値（辞書）のキー「cuisine_list」の値）を引数にレコードを作成
    #    def import_cuisine_list(cuisine_list):
    #        #キー用の連番
    #        key_num = 1
    #        
    #        #Cuisine_infoインスタンスのリスト
    #        #list_cuisine_info_for_return = []
    #        
    #        for cuisine in cuisine_list:
    #            cuisine_info = Cuisine_info(key_num
    #                                            , cuisine['cuisine_name']
    #                                            , cuisine['image']
    #                                            , cuisine['category']
    #                                            , cuisine['cooking_time']
    #                                            , cuisine['how_to_cook']
    #                                            
    #                                            , cuisine['nutrition']['calorie']
    #                                            , cuisine['nutrition']['salt']
    #                                            , cuisine['nutrition']['protein']
    #                                            , cuisine['nutrition']['lipid']
    #                                            , cuisine['nutrition']['carbohydrate']
    #                                            , cuisine['nutrition']['dietary_fiber']
    #                                            , cuisine['nutrition']['iron']
    #                                            , cuisine['nutrition']['calcium']
    #                                            )
    #                                            
    #            #list_cuisine_info_for_return.append(cuisine_info)
    #            db.session.add(cuisine_info)
    #            
    #            key_num += 1
    #            
    #        else:
    #            db.session.commit()
    
    #--材料
    class Ingredient_info(db.Model):
        #キー
        ingredient_id = db.Column(db.Integer, primary_key=True)
        
        #材料名
        ingredient_name = db.Column(db.String(100) , unique=True)
        #単位量
        unit_amount = db.Column(db.Integer)
        #単位
        unit = db.Column(db.String(50))
        
        def __init__(self
                        , ingredient_id
                        , ingredient_name
                        , unit_amount
                        , unit
                        ):
                        
            self.ingredient_id = ingredient_id 
            self.ingredient_name = ingredient_name 
            self.unit_amount = unit_amount
            self.unit= unit
        
        #cuisin_list（関数「get_cuisine_list」の戻り値（辞書）のキー「cuisine_list」の値）を引数にレコードを作成
        #    + 各材料名をキーとし、それに対応するこのテーブルのキーを値とする辞書を戻り値とする。
        #      （Comb_cuisine_ingredient　のレコード作成用）
    #    def import_cuisine_list_and_ingredient_key_dict(cuisine_list):
    #        #キー用の連番
    #        key = 1
    #        
    #        #戻り値（各材料名をキーとし、それに対応するこのテーブルのキーを値とする辞書）
    #        ingredient_key_dict = {}
    #        
    #        for cuisine in cuisine_list:
    #            ingredients = cuisine['ingredients']
    #            
    #            for ingredient_nm in ingredients.keys():
    #                if ingredient_nm not in ingredient_key_dict.keys():
    #                    #レコード作成
    #                    ingredient_info = Ingredient_info(key , ingredient_nm , None , None)
    #                    db.session.add(ingredient_info)
    #                    
    #                    #戻り値（辞書）に登録
    #                    ingredient_key_dict[ingredient_nm] = key
    #                    key += 1
    #                    
    #        db.session.commit()
    #        return ingredient_key_dict
    
    #--お気に入りテーブル
    class User_favorite_cuisine(db.Model):
        #キー
        user_id = db.Column(db.Integer, primary_key=True)
        
        #--連番（各ユーザー毎に、お気に入りに登録した順に付与（n個の料理の組をお気に入りした場合、同じ連番が付与されたnレコードをインサート））
        favorite_seq_number = db.Column(db.Integer, primary_key=True)
        
        #--ランチ、ディナー区分（ランチ：1、ディナー:2）
        lunch_dinner_kbn = db.Column(db.String(1), primary_key=True)
        cuisine_id = db.Column(db.Integer, primary_key=True)
        
        #お気に入りボタンクリック回数
        favorite_click_num = db.Column(db.Integer)
        
        def __init__(self , user_id , favorite_seq_number , lunch_dinner_kbn , cuisine_id):
            self.user_id = user_id
            self.favorite_seq_number = favorite_seq_number
            self.lunch_dinner_kbn = lunch_dinner_kbn
            self.cuisine_id = cuisine_id
            
            #レコード作成時は必ずクリック数は1
            self.favorite_click_num = 1
        
        #お気に入りテーブルに情報登録・更新（テーブルに既存の場合、クリック回数を＋１）
        #※cuisine_name_list ： 対象料理名のリスト（順不同）
        def register_or_update_favorite_info(user_id , lunch_dinner_kbn , cuisine_name_list):
            
            #対象のお気に入りがテーブルに存在してか確認（対象のランチ・ディナー区分に対して、対象の料理の組が全て存在するか確認）
            
            #テーブルに既存⇒True
            fav_data_exist_flg = False
            
            #取得した対象のお気に入りレコードのリスト（対象ユーザー、対象区分で対象の料理が全て取得できたら、既存と判断）
            list_user_favorite_cuisine_info = []
            
            #対象料理のidリスト
            cuisine_id_list = []
            
            #対象料理のid取得
            for cuisine_name in cuisine_name_list:
            
                #対象料理名のキーを取得
                cuisine_info = Cuisine_info.query.filter_by(cuisine_name=cuisine_name).first()
                cuisine_id_list.append(cuisine_info.cuisine_id)
                
            #お気に入りテーブルに既存⇒クリック数を＋１、なければ新規登録
            for cuisine_id in cuisine_id_list:
                    
                #対象の情報がお気に入りテーブルから取得
                user_favorite_cuisine_info = User_favorite_cuisine.query.filter_by(user_id=user_id
                                                                                    , lunch_dinner_kbn=lunch_dinner_kbn
                                                                                    , cuisine_id=cuisine_id
                                                                                    ).first()
                
                if user_favorite_cuisine_info != None:
                    list_user_favorite_cuisine_info.append(user_favorite_cuisine_info)
                else:
                    break
                    
            else:
                #お気に入りテーブルにデータがあるため、フラグをTrueにする。
                fav_data_exist_flg = True
                
                #お気に入りボタンクリック回数を＋１
                for user_favorite_cuisine_info in list_user_favorite_cuisine_info:
                    user_favorite_cuisine_info.favorite_click_num += 1
            
            #存在しない場合はレコード追加
            if fav_data_exist_flg == False:
            
                #次のfor文で最初の処理後にFalseにする
                flg_for_1 = True
                
                #対象ユーザー、対象区分の既存の連番最大値用（次のfor文で最初に取得）
                max_favorite_seq_number = 0
                
                for cuisine_id in cuisine_id_list:
	                #対象ユーザー、対象区分の既存の連番最大値を取得
	                taisho_data_user_and_lunch_dinner_kbn = User_favorite_cuisine.query.filter_by(user_id=user_id
	                                                                                    , lunch_dinner_kbn=lunch_dinner_kbn
	                                                                                    ).all()
                    
	                #対象ユーザー、区分でテーブルにデータが無い時
	                if len(taisho_data_user_and_lunch_dinner_kbn) == 0:
	                    user_favorite_cuisine = User_favorite_cuisine(user_id , 1 , lunch_dinner_kbn , cuisine_id)
	                    db.session.add(user_favorite_cuisine)
	                    
	                    print('いいいいい')
	                    print('user_favorite_cuisine:' , user_favorite_cuisine)
	                    
	                    #最初の処理終了のため、Falseにする
	                    flg_for_1 = False
	                    
	                else:
	                    #for文の最初のみ取得（2回目以降は、1回目に登録したものを考慮してしまうため、+1、+2…となってしまうから。）
	                    if flg_for_1 :
	                        for x in taisho_data_user_and_lunch_dinner_kbn:
	                            seq_number = x.favorite_seq_number
	                            if seq_number > max_favorite_seq_number:
	                                max_favorite_seq_number = seq_number
	                        
	                        print('max_favorite_seq_number:::::' , max_favorite_seq_number)
	                    
	                    user_favorite_cuisine = User_favorite_cuisine(user_id , (max_favorite_seq_number + 1) , lunch_dinner_kbn , cuisine_id)
	                    db.session.add(user_favorite_cuisine)
	                    
	                    print('ああああああ')
	                    print('user_favorite_cuisine:' , user_favorite_cuisine)
	                    
	                    #最初の処理終了のため、Falseにする
	                    flg_for_1 = False
                
            #コミット
            db.session.commit()
    
    # DB ファイル本体を作成し、テーブル作成まで行う
    db.create_all()
    
    #全料理リスト
    cuisine_list = func_list.cuisine_list
    
    #全料理リストをDBに登録
    #--料理・材料テーブル、料理テーブル、材料テーブルにcuisine_listのデータを登録
    Comb_cuisine_ingredient.import_cuisine_list_for_cuisine_and_ingredient_and_comb(cuisine_list)

#インポート時はテーブル定義のみ
else:
    app = Flask(__name__)
    
    
    #データベース構築
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///omame.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
    
    db = SQLAlchemy(app)

    #テーブル定義
    #--テスト
    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        username = db.Column(db.String(80))
        test = db.Column(db.String(80))
    
        def __init__(self, username , test):
            self.username = username
            self.test = test
    
    #--料理と材料の組
    class Comb_cuisine_ingredient(db.Model):
        #キー
        cuisine_id = db.Column(db.Integer, primary_key=True)
        ingredient_id = db.Column(db.Integer, primary_key=True)
        
        #個数
        #ingredient_pieces = db.Column(db.Integer)
        ingredient_pieces = db.Column(db.String(100))
        
        #テスト
        #def testt(self):
            #print('OKOKOKOKOKOKOKOKOKOKOK')
    
        def __init__(self, cuisine_id , ingredient_id , ingredient_pieces):
            self.cuisine_id = cuisine_id
            self.ingredient_id = ingredient_id
            self.ingredient_pieces = ingredient_pieces
            
        #Comb_cuisine_ingredientテーブル、Cuisine_infoテーブル、Ingredient_infoテーブルにcuisine_listのデータを取り込む
        def import_cuisine_list_for_cuisine_and_ingredient_and_comb(cuisine_list):
            #キー用の連番
            cuisine_key = 1
            ingredient_key = 1
            
            #キー：材料名、値：ingredient_id  の辞書（各材料のキー値を保持するために以下で使用）
            ingredient_key_dict = {}
            
            for cuisine in cuisine_list:
                #Cuisine_infoレコード作成
                cuisine_info = Cuisine_info(cuisine_key
                                                , cuisine['cuisine_name']
                                                , cuisine['image']
                                                , cuisine['category']
                                                , cuisine['cooking_time']
                                                , cuisine['how_to_cook']
                                                
                                                , cuisine['nutrition']['calorie']
                                                , cuisine['nutrition']['salt']
                                                , cuisine['nutrition']['protein']
                                                , cuisine['nutrition']['lipid']
                                                , cuisine['nutrition']['carbohydrate']
                                                , cuisine['nutrition']['dietary_fiber']
                                                , cuisine['nutrition']['iron']
                                                , cuisine['nutrition']['calcium']
                                                )
                
                db.session.add(cuisine_info)
    
                #材料取得
                ingredients = cuisine['ingredients']
                
                for ingredient_nm , ingredient_amount in ingredients.items():
                    #まだ対象の材料に連番を付与していない場合は連番を付与して、辞書に登録し、連番を進める
                    if ingredient_nm not in ingredient_key_dict.keys():
                        #材料テーブルレコード作成
                        ingredient_info = Ingredient_info(ingredient_key , ingredient_nm , None , None)
                        db.session.add(ingredient_info)
                        
                        #戻り値（辞書）に登録
                        ingredient_key_dict[ingredient_nm] = ingredient_key
                        ingredient_key += 1
                    
                    #料理・材料テーブルレコード作成
                    #※ifがTrue、Falseでも対象材料が辞書に入っている状態になるので、辞書から連番取得
                    comb_cuisine_ingredient = Comb_cuisine_ingredient(cuisine_key , ingredient_key_dict[ingredient_nm] , ingredient_amount)
                    db.session.add(comb_cuisine_ingredient)
                    
                    cuisine_key += 1
                
            db.session.commit()
            
    #--料理
    class Cuisine_info(db.Model):
        #キー
        cuisine_id = db.Column(db.Integer, primary_key=True)
        
        #料理名
        cuisine_name = db.Column(db.String(100) , unique=True)
        #画像ファイル名（拡張子含む）
        image = db.Column(db.String(100))
        #カテゴリ
        category = db.Column(db.String(100))
        #調理時間
        cooking_time = db.Column(db.Integer)
        #作り方
        how_to_cook = db.Column(db.String(1000))
        
        #栄養
        #--カロリー
        calorie = db.Column(db.Integer)
        #--塩分
        salt = db.Column(db.Integer)
        #--タンパク質
        protein = db.Column(db.Integer)
        #--脂質
        lipid = db.Column(db.Integer)
        #--炭水化物
        carbohydrate = db.Column(db.Integer)
        #--食物繊維
        dietary_fiber = db.Column(db.Integer)
        #--鉄分
        iron = db.Column(db.Integer)
        #--カルシウム
        calcium = db.Column(db.Integer)
        
        def __init__(self
                        , cuisine_id 
                        , cuisine_name
                        , image
                        , category
                        , cooking_time
                        , how_to_cook
                        , calorie
                        , salt
                        , protein
                        , lipid
                        , carbohydrate
                        , dietary_fiber
                        , iron
                        , calcium
                        ):
                        
            self.cuisine_id = cuisine_id 
            self.cuisine_name = cuisine_name 
            self.image= image
            self.category= category
            self.cooking_time= cooking_time
            self.how_to_cook= how_to_cook
            self.calorie= calorie
            self.salt= salt
            self.protein= protein
            self.lipid= lipid
            self.carbohydrate= carbohydrate
            self.dietary_fiber= dietary_fiber
            self.iron= iron
            self.calcium= calcium
            
        #cuisin_list（関数「get_cuisine_list」の戻り値（辞書）のキー「cuisine_list」の値）を引数にレコードを作成
    #    def import_cuisine_list(cuisine_list):
    #        #キー用の連番
    #        key_num = 1
    #        
    #        #Cuisine_infoインスタンスのリスト
    #        #list_cuisine_info_for_return = []
    #        
    #        for cuisine in cuisine_list:
    #            cuisine_info = Cuisine_info(key_num
    #                                            , cuisine['cuisine_name']
    #                                            , cuisine['image']
    #                                            , cuisine['category']
    #                                            , cuisine['cooking_time']
    #                                            , cuisine['how_to_cook']
    #                                            
    #                                            , cuisine['nutrition']['calorie']
    #                                            , cuisine['nutrition']['salt']
    #                                            , cuisine['nutrition']['protein']
    #                                            , cuisine['nutrition']['lipid']
    #                                            , cuisine['nutrition']['carbohydrate']
    #                                            , cuisine['nutrition']['dietary_fiber']
    #                                            , cuisine['nutrition']['iron']
    #                                            , cuisine['nutrition']['calcium']
    #                                            )
    #                                            
    #            #list_cuisine_info_for_return.append(cuisine_info)
    #            db.session.add(cuisine_info)
    #            
    #            key_num += 1
    #            
    #        else:
    #            db.session.commit()
    
    #--材料
    class Ingredient_info(db.Model):
        #キー
        ingredient_id = db.Column(db.Integer, primary_key=True)
        
        #材料名
        ingredient_name = db.Column(db.String(100) , unique=True)
        #単位量
        unit_amount = db.Column(db.Integer)
        #単位
        unit = db.Column(db.String(50))
        
        def __init__(self
                        , ingredient_id
                        , ingredient_name
                        , unit_amount
                        , unit
                        ):
                        
            self.ingredient_id = ingredient_id 
            self.ingredient_name = ingredient_name 
            self.unit_amount = unit_amount
            self.unit= unit
        
        #cuisin_list（関数「get_cuisine_list」の戻り値（辞書）のキー「cuisine_list」の値）を引数にレコードを作成
        #    + 各材料名をキーとし、それに対応するこのテーブルのキーを値とする辞書を戻り値とする。
        #      （Comb_cuisine_ingredient　のレコード作成用）
    #    def import_cuisine_list_and_ingredient_key_dict(cuisine_list):
    #        #キー用の連番
    #        key = 1
    #        
    #        #戻り値（各材料名をキーとし、それに対応するこのテーブルのキーを値とする辞書）
    #        ingredient_key_dict = {}
    #        
    #        for cuisine in cuisine_list:
    #            ingredients = cuisine['ingredients']
    #            
    #            for ingredient_nm in ingredients.keys():
    #                if ingredient_nm not in ingredient_key_dict.keys():
    #                    #レコード作成
    #                    ingredient_info = Ingredient_info(key , ingredient_nm , None , None)
    #                    db.session.add(ingredient_info)
    #                    
    #                    #戻り値（辞書）に登録
    #                    ingredient_key_dict[ingredient_nm] = key
    #                    key += 1
    #                    
    #        db.session.commit()
    #        return ingredient_key_dict
    
    #--お気に入りテーブル
    class User_favorite_cuisine(db.Model):
        #キー
        user_id = db.Column(db.Integer, primary_key=True)
        
        #--連番（各ユーザー毎に、お気に入りに登録した順に付与（n個の料理の組をお気に入りした場合、同じ連番が付与されたnレコードをインサート））
        favorite_seq_number = db.Column(db.Integer, primary_key=True)
        
        #--ランチ、ディナー区分（ランチ：1、ディナー:2）
        lunch_dinner_kbn = db.Column(db.String(1), primary_key=True)
        cuisine_id = db.Column(db.Integer, primary_key=True)
        
        #お気に入りボタンクリック回数
        favorite_click_num = db.Column(db.Integer)
        
        def __init__(self , user_id , favorite_seq_number , lunch_dinner_kbn , cuisine_id):
            self.user_id = user_id
            self.favorite_seq_number = favorite_seq_number
            self.lunch_dinner_kbn = lunch_dinner_kbn
            self.cuisine_id = cuisine_id
            
            #レコード作成時は必ずクリック数は1
            self.favorite_click_num = 1
        
        #お気に入りテーブルに情報登録・更新（テーブルに既存の場合、クリック回数を＋１）
        #※cuisine_name_list ： 対象料理名のリスト（順不同）
        def register_or_update_favorite_info(user_id , lunch_dinner_kbn , cuisine_name_list):
            
            #対象のお気に入りがテーブルに存在してか確認（対象のランチ・ディナー区分に対して、対象の料理の組が全て存在するか確認）
            
            #テーブルに既存⇒True
            fav_data_exist_flg = False
            
            #取得した対象のお気に入りレコードのリスト（対象ユーザー、対象区分で対象の料理が全て取得できたら、既存と判断）
            list_user_favorite_cuisine_info = []
            
            #対象料理のidリスト
            cuisine_id_list = []
            
            #対象料理のid取得
            for cuisine_name in cuisine_name_list:
            
                #対象料理名のキーを取得
                cuisine_info = Cuisine_info.query.filter_by(cuisine_name=cuisine_name).first()
                cuisine_id_list.append(cuisine_info.cuisine_id)
                
            #お気に入りテーブルに既存⇒クリック数を＋１、なければ新規登録
            for cuisine_id in cuisine_id_list:
                    
                #対象の情報がお気に入りテーブルから取得
                user_favorite_cuisine_info = User_favorite_cuisine.query.filter_by(user_id=user_id
                                                                                    , lunch_dinner_kbn=lunch_dinner_kbn
                                                                                    , cuisine_id=cuisine_id
                                                                                    ).first()
                
                if user_favorite_cuisine_info != None:
                    list_user_favorite_cuisine_info.append(user_favorite_cuisine_info)
                else:
                    break
                    
            else:
                #お気に入りテーブルにデータがあるため、フラグをTrueにする。
                fav_data_exist_flg = True
                
                #お気に入りボタンクリック回数を＋１
                for user_favorite_cuisine_info in list_user_favorite_cuisine_info:
                    user_favorite_cuisine_info.favorite_click_num += 1
            
            #存在しない場合はレコード追加
            if fav_data_exist_flg == False:
            
                #次のfor文で最初の処理後にFalseにする
                flg_for_1 = True
                
                #対象ユーザー、対象区分の既存の連番最大値用（次のfor文で最初に取得）
                max_favorite_seq_number = 0
                
                for cuisine_id in cuisine_id_list:
	                #対象ユーザー、対象区分の既存の連番最大値を取得
	                taisho_data_user_and_lunch_dinner_kbn = User_favorite_cuisine.query.filter_by(user_id=user_id
	                                                                                    , lunch_dinner_kbn=lunch_dinner_kbn
	                                                                                    ).all()
                    
	                #対象ユーザー、区分でテーブルにデータが無い時
	                if len(taisho_data_user_and_lunch_dinner_kbn) == 0:
	                    user_favorite_cuisine = User_favorite_cuisine(user_id , 1 , lunch_dinner_kbn , cuisine_id)
	                    db.session.add(user_favorite_cuisine)
	                    
	                    print('いいいいい')
	                    print('user_favorite_cuisine:' , user_favorite_cuisine)
	                    
	                    #最初の処理終了のため、Falseにする
	                    flg_for_1 = False
	                    
	                else:
	                    #for文の最初のみ取得（2回目以降は、1回目に登録したものを考慮してしまうため、+1、+2…となってしまうから。）
	                    if flg_for_1 :
	                        for x in taisho_data_user_and_lunch_dinner_kbn:
	                            seq_number = x.favorite_seq_number
	                            if seq_number > max_favorite_seq_number:
	                                max_favorite_seq_number = seq_number
	                        
	                        print('max_favorite_seq_number:::::' , max_favorite_seq_number)
	                    
	                    user_favorite_cuisine = User_favorite_cuisine(user_id , (max_favorite_seq_number + 1) , lunch_dinner_kbn , cuisine_id)
	                    db.session.add(user_favorite_cuisine)
	                    
	                    print('ああああああ')
	                    print('user_favorite_cuisine:' , user_favorite_cuisine)
	                    
	                    #最初の処理終了のため、Falseにする
	                    flg_for_1 = False
                
            #コミット
            db.session.commit()