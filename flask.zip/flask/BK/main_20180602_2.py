# coding: utf-8
from flask import Flask, render_template , request , url_for , redirect
import func_list

#全料理リスト
cuisine_list = func_list.cuisine_list

#選択カテゴリ_dinner
list_taisho_cuisine_cate_key_dinner = ['主菜' , '副菜']
list_taisho_cuisine_cate_key_lunch = ['主菜']

#調理時間（初期）
selected_cooking_time = 30

#選択料理_dinner（初期）
selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)




#選択料理の画像_dinner（主菜、副菜）
mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'

mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'

print('mainimg_dinner')
print(mainimg_dinner)
print('subimg_dinner')
print(subimg_dinner)
print('mainimg_lunch')
print(mainimg_lunch)

app = Flask(__name__)


#@app.route("/")
#def hello():
#  return "Hello World!"


#初期
@app.route("/")
def index():
    #return render_template('omame1.html', message=hello)
    return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , mainimg_lunch=mainimg_lunch)
    
#ボタンクリック
@app.route("/" , methods=['POST'])
def index_post():
    #return render_template('omame1.html', message=hello)
    
    #print('bbbbbbb')
    #print(request.method)
    #print(request.form)
    #print(request.args)
    #print(list(request.form.keys()))
    #print('change_dinner.x' in list(request.form.keys()))
    
    #ディナーの再選択
    if 'change_dinner.x' in list(request.form.keys()):
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
    
        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , mainimg_lunch=mainimg_lunch)
    
    #ランチの再選択
    elif 'change_lunch.x' in list(request.form.keys()):
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
    
        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , mainimg_lunch=mainimg_lunch)

if __name__ == "__main__":
    app.run()