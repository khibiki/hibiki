# DB 周りを import
from main import db, User
import os

#print('テーブル削除スタート')
#User.query.delete()
#db.session.commit()
#print('テーブル削除完了')

#既存DBファイルがある場合は削除
omame_db_file_path = os.path.join(os.path.abspath('.') , 'omame.db')
if os.path.exists(omame_db_file_path):
    print('存在')
    os.remove(omame_db_file_path)

# DB ファイル本体を作成し、テーブル作成まで行う
db.create_all()
