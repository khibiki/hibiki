# coding: utf-8
from flask import Flask, render_template , request , url_for , redirect
import func_list
from func_list import random_cuisine_choice
from func_list import summary_ingredients_info
from func_list import process_notation_ingredients
from func_list import process_notation_how_to_cook
import inspect

from flask_sqlalchemy import SQLAlchemy
#from setting import session

from create_table import *
#User , Comb_cuisine_ingredient , Cuisine_info , Ingredient_info , User_favorite_cuisine




#全料理リスト
cuisine_list = func_list.cuisine_list

#テスト
#i = 0
#for cuisine in cuisine_list:
#    for x in cuisine['ingredients']:
#        i += 1
#print('総和：：：' , i)

#テスト
#test_comb_cuisine_ingredient = db.session.query(Comb_cuisine_ingredient).all()
#print('テストtest_comb_cuisine_ingredientスタート--------------------')
#for row in test_comb_cuisine_ingredient:
#    print('＊' * 30)
#    print('cuisine_id:' , row.cuisine_id)
#    print('ingredient_id:' , row.ingredient_id)
#    print('ingredient_pieces:' , row.ingredient_pieces)
#    print('＊' * 30)
#print('長さ:' , len(test_comb_cuisine_ingredient))
#print('テストtest_comb_cuisine_ingredientエンド--------------------')

#テスト
#test_cuisine_info = db.session.query(Cuisine_info).all()
#print('テストtest_cuisine_infoスタート--------------------')
#for row in test_cuisine_info:
#    print('＊' * 30)
#    print('cuisine_id:' , row.cuisine_id)
#    print('cuisine_name:' , row.cuisine_name)
#    print('image:' , row.image)
#    print('category:' , row.category)
#    print('cooking_time:' , row.cooking_time)
#    print('how_to_cook:' , row.how_to_cook)
#    print('calorie:' , row.calorie)
#    print('salt:' , row.salt)
#    print('protein:' , row.protein)
#    print('lipid:' , row.lipid)
#    print('carbohydrate:' , row.carbohydrate)
#    print('dietary_fiber:' , row.dietary_fiber)
#    print('iron:' , row.iron)
#    print('calcium:' , row.calcium)
#    print('＊' * 30)
#print('長さ:' , len(test_cuisine_info))
#print('テストtest_cuisine_infoエンド--------------------')

#テスト
#test_ingredient_info = db.session.query(Ingredient_info).all()
#print('テストtest_ingredient_infoスタート--------------------')
#print(test_ingredient_info)
#for row in test_ingredient_info:
#    print('＊' * 30)
#    print('ingredient_id:' , row.ingredient_id)
#    print('ingredient_name:' , row.ingredient_name)
#    print('unit_amount:' , row.unit_amount)
#    print('unit:' , row.unit)
#    print('＊' * 30)
#
#print('長さ:' , len(test_ingredient_info))
#print('テストtest_ingredient_infoエンド--------------------')




#■■■■■■■■■■■■■■■関数_start
#お気に入り画面用情報取得
#引数：user_id
#戻り値：お気に入りテーブルの各レコードの情報（辞書）を要素とするリスト
def get_list_fav_dict(user_id):
    global fav_kgr
    
    #--対象ユーザーのお気に入り情報をDBから取得
    user_fav_info_all = User_favorite_cuisine.query.filter_by(user_id=user_id).all()
    
    print('user_fav_info_all:' , user_fav_info_all)
    
    #--リスト作成（宿題：ディナー用化）
    list_user_fav_info_all = []
    for row in user_fav_info_all:
        print('bbbbbbbbbbbb')
        dict = {}
        
        dict['user_id'] = row.user_id
        dict['lunch_dinner_kbn'] = row.lunch_dinner_kbn
        dict['cuisine_id'] = row.cuisine_id
        dict['favorite_click_num'] = row.favorite_click_num
        
        record_cuisine_info = Cuisine_info.query.filter_by(cuisine_id=row.cuisine_id).first()
        
        dict['cuisine_name'] = record_cuisine_info.cuisine_name
        
        #画像
        img_path = record_cuisine_info.cuisine_name + '.png'
        
        dict['img_path'] = img_path
        
        #テスト
        print('img_path:' , img_path)
        
        #選択ボタンのname用        
        fav_button_name = 'fav_info' + fav_kgr  + row.lunch_dinner_kbn + fav_kgr +  (fav_kgr.join([str(row.cuisine_id)]))
        dict['fav_button_name'] = fav_button_name
        
        #テスト
        print('fav_button_name:' , fav_button_name)
        
        list_user_fav_info_all.append(dict)
        
    return list_user_fav_info_all






#■■■■■■■■■■■■■■■関数_end

#お気に入りの選択ボタンのnameの区切り文字
fav_kgr = r"_3w27di9_"


#選択カテゴリ_dinner、lunch
list_taisho_cuisine_cate_key_dinner = ['主菜' , '副菜']
list_taisho_cuisine_cate_key_lunch = ['主菜']

#調理時間（初期）
selected_cooking_time = 30

#選択料理_dinner、lunch（初期）
selected_cuisines_dinner = random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
selected_cuisines_lunch = random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

#材料リスト_dinner、lunch（初期）
ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)

#作り方_dinner、lunch（初期）
how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))


#選択料理の画像_dinner（主菜、副菜）
mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'

#選択料理の画像_lunch（主菜）
mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'


#選択料理の名前_dinner（主菜、副菜）
name_mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name']
name_subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name']

#選択料理の名前_lunch（主菜）
name_mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name']


#お気に入り画面用情報取得
list_user_fav_info_all = get_list_fav_dict(9999)
print('list_user_fav_info_all:' , list_user_fav_info_all)









print('mainimg_dinner')
print(mainimg_dinner)
print('subimg_dinner')
print(subimg_dinner)
print('mainimg_lunch')
print(mainimg_lunch)



#@app.route("/")
#def hello():
#  return "Hello World!"


#初期
@app.route("/")
def index():
    #return render_template('omame1.html', message=hello)
    return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                , name_mainimg_dinner = name_mainimg_dinner
                                , name_subimg_dinner = name_subimg_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch
                                , name_mainimg_lunch = name_mainimg_lunch
                                
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
    
#ボタンクリック
@app.route("/" , methods=['POST'])
def index_post():
    #return render_template('omame1.html', message=hello)
    
    #テスト
    user_fav_info_all = User_favorite_cuisine.query.filter_by(user_id='9999').all()
    print('user_fav_info_all:' , user_fav_info_all)
    
    #エラー「UnboundLocalError」を防ぐためにglobal化
    global selected_cuisines_dinner
    global selected_cuisines_lunch
    
    print('bbbbbbb')
    print(request.method)
    print(request.form)
    print(request.args)
    print(list(request.form.keys()))
    print('change_dinner.x' in list(request.form.keys()))
    
    print("メソッド一覧")
    print("-" * 30)
    for x in inspect.getmembers(request, inspect.ismethod):
        print(x[0])
    print("-" * 30)
    print(request.from_values())
    print(request.get_data())
    print(request.data)
    print(request.values)
    
    #ディナーの再選択
    if 'change_dinner.x' in list(request.form.keys()):        
        #データベースの中身確認
        print('dbの中身確認_前')
        all_db_info = db.session.query(User).all()
        
        print('start_all_db-----------------')
        print(all_db_info)
        for row in all_db_info:
             print("%d, %s" % (row.id, row.username))

        print('end_all_db-----------------')
        
        
        #データベースに登録
        print('DB登録')
        user = User(selected_cuisines_dinner['主菜']['cuisine_name'] , 'tttt')
        db.session.add(user)
        db.session.commit()
        user = User(selected_cuisines_dinner['副菜']['cuisine_name'] , 'sssss')
        db.session.add(user)
        db.session.commit()
        
        #データベースの中身確認
        print('dbの中身確認_後')
        all_db_info = db.session.query(User).all()
        
        print('start_all_db-----------------')
        print(all_db_info)
        for row in all_db_info:
             print("%d, %s" % (row.id, row.username))

        print('end_all_db-----------------')
        
        #print('テストスタートCuisine_info--------------------------')
        #print('テストエンドCuisine_info--------------------------')
        
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #材料リスト_dinner、lunch
        ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
        process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

        ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
        process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)
        
        #作り方_dinner、lunch
        how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
        how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))


        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
        
        #選択料理の名前_dinner（主菜、副菜）
        name_mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name']
        name_subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name']
        #選択料理の名前_lunch（主菜）
        name_mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name']
        
        
        #お気に入り登録
        User_favorite_cuisine.register_or_update_favorite_info(9999 , '2' , name_mainimg_dinner)
        User_favorite_cuisine.register_or_update_favorite_info(9999 , '2' , name_subimg_dinner)
        
        #テスト
        test_ufc = db.session.query(User_favorite_cuisine).all()
        
        for row in test_ufc:
            print("start_" + "あ" * 30)
            print("user_id:" , row.user_id)
            print("lunch_dinner_kbn:" , row.lunch_dinner_kbn)
            print("cuisine_id:" , row.cuisine_id)
            print("favorite_click_num:" , row.favorite_click_num)
            print("end_" + "あ" * 30)

        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                , name_mainimg_dinner = name_mainimg_dinner
                                , name_subimg_dinner = name_subimg_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch
                                , name_mainimg_lunch = name_mainimg_lunch
                                
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
    
    #ランチの再選択
    elif 'change_lunch.x' in list(request.form.keys()):    
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #材料リスト_dinner、lunch
        ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
        process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

        ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
        process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)

        #作り方_dinner、lunch
        how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
        how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))

        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'

        #選択料理の名前_dinner（主菜、副菜）
        name_mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name']
        name_subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name']
        #選択料理の名前_lunch（主菜）
        name_mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name']
        
        #お気に入り登録
        User_favorite_cuisine.register_or_update_favorite_info(9999 , '1' , name_mainimg_lunch)
        

        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                , name_mainimg_dinner = name_mainimg_dinner
                                , name_subimg_dinner = name_subimg_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch
                                , name_mainimg_lunch = name_mainimg_lunch
                                
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
                                
    #お気に入りの一つを選択したとき
    elif 'fav_info' in list(map(lambda x:x[:8] , request.form.keys())):
        #テスト
        print('いえええええええい')
        print(list(map(lambda x:x[:7] , request.form.keys())))
        
        clicked_fav_img_name = list(filter(lambda x:x[:8] == 'fav_info' , request.form.keys()))[0].replace('.x' ,  '').replace('.y' , '')
        
        print('clicked_fav_img_name:' , clicked_fav_img_name)
        
        #ランチ・ディナー区分、料理情報を取得
        lunch_dinner_kbn = str(clicked_fav_img_name.split(fav_kgr)[1])
        selected_fav_cuisine_id_list = clicked_fav_img_name.split(fav_kgr)[2:]
        
        print('selected_fav_cuisine_id_list:' , selected_fav_cuisine_id_list)

        #料理情報をキー：カテゴリ、値：料理情報（selected_cuisines_dinnerなどに入れる値）として辞書に格納
        selected_fav_cuisine_dict = {}
        
        for cuisine_id in selected_fav_cuisine_id_list:
            fav_cuisine_info = Cuisine_info.query.filter_by(cuisine_id=cuisine_id).first()
            selected_fav_cuisine_dict[fav_cuisine_info.category] = fav_cuisine_info.cuisine_name
            
        #ランチの場合
        if lunch_dinner_kbn == '1':
            selected_cuisines_lunch = {}
            for category_nm , cuisine_nm in selected_fav_cuisine_dict.items():
                #料理名から、対象の料理情報を取得
                fav_cuisine_info = list(filter(lambda x:x['cuisine_name'] == cuisine_nm , cuisine_list))[0]
                selected_cuisines_lunch[category_nm] = fav_cuisine_info
            
            #以下は他の条件（「ランチの再選択」など）と同様に値設定
            #材料リスト_dinner、lunch
            ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
            process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

            ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
            process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)
        
            #作り方_dinner、lunch
            how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
            how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))
            
            #テスト
            print('ここでエラー')

            #選択料理の画像_dinner（主菜、副菜）
            mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
            subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
            #選択料理の画像_lunch（主菜、副菜）
            mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
        
            #選択料理の名前_dinner（主菜、副菜）
            name_mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name']
            name_subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name']
            #選択料理の名前_lunch（主菜）
            name_mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name']
        #ディナーの場合
        else:
            selected_cuisines_dinner = {}
            for category_nm , cuisine_nm in selected_fav_cuisine_dict.items():
                #料理名から、対象の料理情報を取得
                fav_cuisine_info = list(filter(lambda x:x['cuisine_name'] == cuisine_nm , cuisine_list))[0]
                selected_cuisines_dinner[category_nm] = fav_cuisine_info
            
            #以下は他の条件（「ランチの再選択」など）と同様に値設定
            #材料リスト_dinner、lunch
            ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
            process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

            ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
            process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)
        
            #作り方_dinner、lunch
            how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
            how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))


            #選択料理の画像_dinner（主菜、副菜）
            mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
            subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
            #選択料理の画像_lunch（主菜、副菜）
            mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
        
            #選択料理の名前_dinner（主菜、副菜）
            name_mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name']
            name_subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name']
            #選択料理の名前_lunch（主菜）
            name_mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name']

        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                , name_mainimg_dinner = name_mainimg_dinner
                                , name_subimg_dinner = name_subimg_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch
                                , name_mainimg_lunch = name_mainimg_lunch
                                
                                , list_user_fav_info_all = list_user_fav_info_all
                                )

if __name__ == "__main__":
    app.run()