# DB 周りを import
#from main import db
import os
from flask import Flask, render_template , request , url_for , redirect
from flask_sqlalchemy import SQLAlchemy

#print('テーブル削除スタート')
#User.query.delete()
#db.session.commit()
#print('テーブル削除完了')

#既存DBファイルがある場合は削除
omame_db_file_path = os.path.join(os.path.abspath('.') , 'omame.db')
if os.path.exists(omame_db_file_path):
    print('存在')
    os.remove(omame_db_file_path)

app = Flask(__name__)


#データベース構築
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///omame.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)

#テーブル定義
#--テスト
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80))
    test = db.Column(db.String(80))

    def __init__(self, username , test):
        self.username = username
        self.test = test

#--料理と材料の組
class Comb_cuisine_ingredient(db.Model):
    #キー
    cuisine_id = db.Column(db.Integer, primary_key=True)
    ingredient_id = db.Column(db.Integer, primary_key=True)
    
    #個数
    ingredient_pieces = db.Column(db.Integer)
    
    #テスト
    #def testt(self):
        #print('OKOKOKOKOKOKOKOKOKOKOK')

    def __init__(self, cuisine_id , ingredient_id , ingredient_pieces):
        self.cuisine_id = cuisine_id
        self.ingredient_id = ingredient_id
        self.ingredient_pieces = ingredient_pieces
        
#--料理
class Cuisine_info(db.Model):
    #キー
    cuisine_id = db.Column(db.Integer, primary_key=True)
    
    #料理名
    cuisine_name = db.Column(db.String(100))
    #画像ファイル名（拡張子含む）
    image = db.Column(db.String(100))
    #カテゴリ
    category = db.Column(db.String(100))
    #調理時間
    cooking_time = db.Column(db.Integer)
    #作り方
    how_to_cook = db.Column(db.String(1000))
    
    #栄養
    #--カロリー
    calorie = db.Column(db.Integer)
    #--塩分
    salt = db.Column(db.Integer)
    #--タンパク質
    protein = db.Column(db.Integer)
    #--脂質
    lipid = db.Column(db.Integer)
    #--炭水化物
    carbohydrate = db.Column(db.Integer)
    #--食物繊維
    dietary_fiber = db.Column(db.Integer)
    #--鉄分
    iron = db.Column(db.Integer)
    #--カルシウム
    calcium = db.Column(db.Integer)
    
    def __init__(self
                    , cuisine_id 
                    , cuisine_name
                    , image
                    , category
                    , cooking_time
                    , how_to_cook
                    , calorie
                    , salt
                    , protein
                    , lipid
                    , carbohydrate
                    , dietary_fiber
                    , iron
                    , calcium
                    ):
                    
        self.cuisine_id = cuisine_id 
        self.cuisine_name = cuisine_name 
        self.image= image
        self.category= category
        self.cooking_time= cooking_time
        self.how_to_cook= how_to_cook
        self.calorie= calorie
        self.salt= salt
        self.protein= protein
        self.lipid= lipid
        self.carbohydrate= carbohydrate
        self.dietary_fiber= dietary_fiber
        self.iron= iron
        self.calcium= calcium
        
    #cuisin_list（関数「get_cuisine_list」の戻り値（辞書）のキー「cuisine_list」の値）を引数にレコードを作成
    def import_cuisine_list(cuisine_list):
        #キー用の連番
        key_num = 1
        
        #Cuisine_infoインスタンスのリスト
        #list_cuisine_info_for_return = []
        
        for cuisine in cuisine_list:
            cuisine_info = Cuisine_info(key_num
                                            , cuisine['cuisine_name']
                                            , cuisine['image']
                                            , cuisine['category']
                                            , cuisine['cooking_time']
                                            , cuisine['how_to_cook']
                                            
                                            , cuisine['nutrition']['calorie']
                                            , cuisine['nutrition']['salt']
                                            , cuisine['nutrition']['protein']
                                            , cuisine['nutrition']['lipid']
                                            , cuisine['nutrition']['carbohydrate']
                                            , cuisine['nutrition']['dietary_fiber']
                                            , cuisine['nutrition']['iron']
                                            , cuisine['nutrition']['calcium']
                                            )
                                            
            #list_cuisine_info_for_return.append(cuisine_info)
            db.session.add(cuisine_info)
            
            key_num += 1
            
        else:
            db.session.commit()

#--材料
class Ingredient_info(db.Model):
    #キー
    ingredient_id = db.Column(db.Integer, primary_key=True)
    
    #材料名
    ingredient_name = db.Column(db.String(100))
    #単位量
    unit_amount = db.Column(db.Integer)
    #単位
    unit = db.Column(db.String(50))
    
    def __init__(self
                    , ingredient_id
                    , ingredient_name
                    , unit_amount
                    , unit
                    ):
                    
        self.ingredient_id = ingredient_id 
        self.ingredient_name = ingredient_name 
        self.unit_amount = unit_amount
        self.unit= unit


# DB ファイル本体を作成し、テーブル作成まで行う
db.create_all()
