# coding: utf-8
from flask import Flask, render_template , request , url_for , redirect
import func_list
from func_list import random_cuisine_choice
from func_list import summary_ingredients_info
from func_list import process_notation_ingredients
from func_list import process_notation_how_to_cook
import inspect

from flask_sqlalchemy import SQLAlchemy
#from setting import session


#全料理リスト
cuisine_list = func_list.cuisine_list

#選択カテゴリ_dinner、lunch
list_taisho_cuisine_cate_key_dinner = ['主菜' , '副菜']
list_taisho_cuisine_cate_key_lunch = ['主菜']

#調理時間（初期）
selected_cooking_time = 30

#選択料理_dinner、lunch（初期）
selected_cuisines_dinner = random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
selected_cuisines_lunch = random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

#材料リスト_dinner、lunch（初期）
ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)

#作り方_dinner、lunch（初期）
how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))


#選択料理の画像_dinner（主菜、副菜）
mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'

#選択料理の画像_lunch（主菜）
mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'

print('mainimg_dinner')
print(mainimg_dinner)
print('subimg_dinner')
print(subimg_dinner)
print('mainimg_lunch')
print(mainimg_lunch)

app = Flask(__name__)


#データベース構築
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///omame.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80))
    test = db.Column(db.String(80))

    def __init__(self, username , test):
        self.username = username
        self.test = test




#@app.route("/")
#def hello():
#  return "Hello World!"


#初期
@app.route("/")
def index():
    #return render_template('omame1.html', message=hello)
    return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch)
    
#ボタンクリック
@app.route("/" , methods=['POST'])
def index_post():
    #return render_template('omame1.html', message=hello)
    
    print('bbbbbbb')
    print(request.method)
    print(request.form)
    print(request.args)
    print(list(request.form.keys()))
    print('change_dinner.x' in list(request.form.keys()))
    
    print("メソッド一覧")
    print("-" * 30)
    for x in inspect.getmembers(request, inspect.ismethod):
        print(x[0])
    print("-" * 30)
    print(request.from_values())
    print(request.get_data())
    print(request.data)
    print(request.values)
    
    #ディナーの再選択
    if 'change_dinner.x' in list(request.form.keys()):
        #エラー「UnboundLocalError」を防ぐためにglobal化
        global selected_cuisines_dinner
        
        #データベースの中身確認
        print('dbの中身確認_前')
        all_db_info = db.session.query(User).all()
        
        print('start_all_db-----------------')
        print(all_db_info)
        for row in all_db_info:
             print("%d, %s" % (row.id, row.username))

        print('end_all_db-----------------')
        
        
        #データベースに登録
        print('DB登録')
        user = User(selected_cuisines_dinner['主菜']['cuisine_name'] , 'tttt')
        db.session.add(user)
        db.session.commit()
        user = User(selected_cuisines_dinner['副菜']['cuisine_name'] , 'sssss')
        db.session.add(user)
        db.session.commit()
        
        #データベースの中身確認
        print('dbの中身確認_後')
        all_db_info = db.session.query(User).all()
        
        print('start_all_db-----------------')
        print(all_db_info)
        for row in all_db_info:
             print("%d, %s" % (row.id, row.username))

        print('end_all_db-----------------')
    
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #材料リスト_dinner、lunch
        ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
        process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

        ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
        process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)
        
        #作り方_dinner、lunch
        how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
        how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))


        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
    
        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch)
    
    #ランチの再選択
    elif 'change_lunch.x' in list(request.form.keys()):
        #選択料理_dinner（再取得）
        selected_cuisines_dinner = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_dinner , selected_cooking_time)
        #選択料理_lunch（再取得）
        selected_cuisines_lunch = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key_lunch , selected_cooking_time)

        #材料リスト_dinner、lunch
        ingredients_summary_dinner = summary_ingredients_info(list(selected_cuisines_dinner.values()))
        process_notation_ingredients_dinner = process_notation_ingredients(ingredients_summary_dinner)

        ingredients_summary_lunch = summary_ingredients_info(list(selected_cuisines_lunch.values()))
        process_notation_ingredients_lunch = process_notation_ingredients(ingredients_summary_lunch)

        #作り方_dinner、lunch
        how_to_cook_dinner = process_notation_how_to_cook(list(selected_cuisines_dinner.values()))
        how_to_cook_lunch = process_notation_how_to_cook(list(selected_cuisines_lunch.values()))

        #選択料理の画像_dinner（主菜、副菜）
        mainimg_dinner = selected_cuisines_dinner['主菜']['cuisine_name'] + '.png'
        subimg_dinner = selected_cuisines_dinner['副菜']['cuisine_name'] + '.png'
        #選択料理の画像_lunch（主菜、副菜）
        mainimg_lunch = selected_cuisines_lunch['主菜']['cuisine_name'] + '.png'
    
        return render_template('omame1.html' 
                                , mainimg_dinner=mainimg_dinner
                                , subimg_dinner=subimg_dinner
                                , process_notation_ingredients_dinner = process_notation_ingredients_dinner
                                , how_to_cook_dinner = how_to_cook_dinner
                                
                                , mainimg_lunch=mainimg_lunch
                                , process_notation_ingredients_lunch = process_notation_ingredients_lunch
                                , how_to_cook_lunch = how_to_cook_lunch)

if __name__ == "__main__":
    app.run()