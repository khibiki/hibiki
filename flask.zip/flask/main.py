# coding: utf-8
from flask import Flask, render_template , request , url_for , redirect
import func_list
from func_list import random_cuisine_choice
from func_list import summary_ingredients_info
from func_list import process_notation_ingredients
from func_list import process_notation_how_to_cook
import inspect

from flask_sqlalchemy import SQLAlchemy
#from setting import session

from create_table import *
#User , Comb_cuisine_ingredient , Cuisine_info , Ingredient_info , User_favorite_cuisine




#全料理リスト
cuisine_list = func_list.cuisine_list

#お気に入りの選択ボタンのnameの区切り文字
fav_kgr = r"_3w27di9_"

#選択カテゴリ_dinner、lunch
list_taisho_cuisine_cate_key_dinner = ['主菜' , '副菜']
list_taisho_cuisine_cate_key_lunch = ['主菜']

#ランチ、ディナー区分（ランチ：1、ディナー:2）
lunch_kbn = '1'
dinner_kbn = '2'

#■■■■■■■■■■■■■■■関数_start
#お気に入り画面用情報取得
#引数：user_id
#戻り値：お気に入りテーブルの各レコードの情報（辞書）を要素とするリスト
def get_list_fav_dict(user_id):
    global fav_kgr
    
    #--対象ユーザーのお気に入り情報をDBから取得
    user_fav_info_all = User_favorite_cuisine.query.filter_by(user_id=user_id).all()
    
    #--リスト作成
    list_user_fav_info_all = []
    for row in user_fav_info_all:
        dict = {}
        
        dict['user_id'] = row.user_id
        dict['favorite_seq_number'] = row.favorite_seq_number
        dict['lunch_dinner_kbn'] = row.lunch_dinner_kbn
        
        #※リストであることに注意
        dict['cuisine_id_list'] = [str(row.cuisine_id)]
        
        dict['favorite_click_num'] = row.favorite_click_num
        
        #料理名
        record_cuisine_info = Cuisine_info.query.filter_by(cuisine_id=row.cuisine_id).first()
        dict['cuisine_name_list'] = [record_cuisine_info.cuisine_name]
        
        #画像
        img_path = record_cuisine_info.cuisine_name + '.png'
        dict['img_path_list'] = [img_path]
        
        #料理名、画像の辞書のリスト
        dict['list_dict_cuisine_name_img_path'] = [{'cuisine_name':record_cuisine_info.cuisine_name , 'img_path':img_path}]
        
        print('検索対象:::' , dict)
        
        #list_user_fav_info_allに、既に対象のユーザー×区分×連番のデータが存在する場合、既存分のdict['cuisine_id_list']（リスト）に今回分も追加し、今回分は辞書に追加しない。
        flg_exist_in_list = False
        for i in range(len(list_user_fav_info_all)):
            
            print('fooo_list_user_fav_info_all[i]:::' , list_user_fav_info_all[i])
            
            existing_dict = list_user_fav_info_all[i]
            
            if existing_dict['user_id'] == row.user_id and existing_dict['lunch_dinner_kbn'] == row.lunch_dinner_kbn and existing_dict['favorite_seq_number'] == row.favorite_seq_number:
                print('TRUE' * 10)
                
                #存在フラグをTrueにする
                flg_exist_in_list = True
                
                #既存分のdict['cuisine_id_list']（リスト）に今回分も追加
                existing_dict['cuisine_id_list'].append(str(row.cuisine_id))
                
                #既存分のdict['cuisine_name_list']（リスト）に今回分も追加
                existing_dict['cuisine_name_list'].append(record_cuisine_info.cuisine_name)
                
                #既存分のdict['img_path_list']（リスト）に今回分も追加
                existing_dict['img_path_list'].append(img_path)
                
                #既存分のdict['list_dict_cuisine_name_img_path']（リスト）に今回分も追加
                existing_dict['list_dict_cuisine_name_img_path'].append({'cuisine_name':record_cuisine_info.cuisine_name , 'img_path':img_path})
                
                
                #選択ボタンのname用を更新（今回分も追加）
                fav_button_name = 'fav_info' + fav_kgr  + row.lunch_dinner_kbn + fav_kgr + (fav_kgr.join(existing_dict['cuisine_id_list']))
                existing_dict['fav_button_name'] = fav_button_name
                
                #更新した辞書をリストに反映
                list_user_fav_info_all[i] = existing_dict
                
                break
                
        #既存でない場合、新規追加
        if flg_exist_in_list == False :
            print('FALSE' * 10)
            #選択ボタンのname用
            fav_button_name = 'fav_info' + fav_kgr  + row.lunch_dinner_kbn + fav_kgr + (fav_kgr.join([str(row.cuisine_id)]))
            dict['fav_button_name'] = fav_button_name
            
            list_user_fav_info_all.append(dict)
    
    print('list_user_fav_info_all:::' , list_user_fav_info_all)
    return list_user_fav_info_all

#表示情報更新関数
#引数：料理リスト、ランチ用対象料理カテゴリ、選択調理時間
#戻り値：htmlに渡す情報（辞書）
def set_show_info(cuisine_list , list_taisho_cuisine_cate_key , selected_cooking_time):
    #戻り値になる辞書
    dict_for_return = {}
    
    #--料理情報ランダム取得
    selected_cuisines = func_list.random_cuisine_choice(cuisine_list , list_taisho_cuisine_cate_key , selected_cooking_time)
    
    #--材料リスト取得
    ingredients_summary = summary_ingredients_info(list(selected_cuisines.values()))
    notation_ingredients = process_notation_ingredients(ingredients_summary)
    
    #--作り方取得
    how_to_cook = process_notation_how_to_cook(list(selected_cuisines.values()))
    
    #--主食
    #----画像
    mainimg = selected_cuisines['主菜']['cuisine_name'] + '.png'
    #----名前
    name_mainimg = selected_cuisines['主菜']['cuisine_name']
    
    #--副菜（引数のカテゴリリストに無ければ、None）
    if '副菜' in list_taisho_cuisine_cate_key :
        subimg = selected_cuisines['副菜']['cuisine_name'] + '.png'
        name_subimg = selected_cuisines['副菜']['cuisine_name']
    else:
        subimg = None
        name_subimg = None
    
    #情報を戻り値（辞書）に格納
    dict_for_return['notation_ingredients'] = notation_ingredients
    dict_for_return['how_to_cook'] = how_to_cook
    dict_for_return['mainimg'] = mainimg
    dict_for_return['name_mainimg'] = name_mainimg
    dict_for_return['subimg'] = subimg
    dict_for_return['name_subimg'] = name_subimg

    return dict_for_return

#■■■■■■■■■■■■■■■関数_end

#■■■■■■■■■■■■■■■初期表示情報_start
#ランチ
show_info_lunch = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_lunch , 30)

#ディナー
show_info_dinner = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_dinner , 30)

#お気に入り画面用情報取得
list_user_fav_info_all = get_list_fav_dict(9999)

#■■■■■■■■■■■■■■■初期表示情報_end

#初期
@app.route("/")
def index():
    #return render_template('omame1.html', message=hello)                                
    return render_template('omame1.html' 
                                , show_info_lunch = show_info_lunch
                                , show_info_dinner = show_info_dinner
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
    
#ボタンクリック
@app.route("/" , methods=['POST'])
def index_post():
    #return render_template('omame1.html', message=hello)
    
    #エラー「UnboundLocalError」を防ぐためにglobal化
    global show_info_lunch
    global show_info_dinner
    
    #ディナーの再選択
    if 'change_dinner.x' in list(request.form.keys()):
        #お気に入り登録
        User_favorite_cuisine.register_or_update_favorite_info(9999 , dinner_kbn , [show_info_dinner['name_mainimg'] , show_info_dinner['name_subimg']])
        
        #ランチ
        ###show_info_lunch = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_lunch , 30)
        
        #ディナー
        show_info_dinner = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_dinner , 30)
        
        #お気に入り画面用情報取得
        list_user_fav_info_all = get_list_fav_dict(9999)
        
        return render_template('omame1.html' 
                                , show_info_lunch = show_info_lunch
                                , show_info_dinner = show_info_dinner
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
    
    #ランチの再選択
    elif 'change_lunch.x' in list(request.form.keys()):
        #お気に入り登録
        User_favorite_cuisine.register_or_update_favorite_info(9999 , lunch_kbn , [show_info_lunch['name_mainimg']])
        
        #ランチ
        show_info_lunch = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_lunch , 30)
        
        #ディナー
        ###show_info_dinner = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_dinner , 30)
        
        #お気に入り画面用情報取得
        list_user_fav_info_all = get_list_fav_dict(9999)
        
        return render_template('omame1.html' 
                                , show_info_lunch = show_info_lunch
                                , show_info_dinner = show_info_dinner
                                , list_user_fav_info_all = list_user_fav_info_all
                                )
                                
    #お気に入りの一つを選択したとき
    elif 'fav_info' in list(map(lambda x:x[:8] , request.form.keys())):
        
        clicked_fav_img_name = list(filter(lambda x:x[:8] == 'fav_info' , request.form.keys()))[0].replace('.x' ,  '').replace('.y' , '')
        
        print('clicked_fav_img_name:' , clicked_fav_img_name)
        
        #ランチ・ディナー区分、料理情報を取得
        lunch_dinner_kbn = str(clicked_fav_img_name.split(fav_kgr)[1])
        selected_fav_cuisine_id_list = clicked_fav_img_name.split(fav_kgr)[2:]
        
        print('aaaa' * 30)
        print('selected_fav_cuisine_id_list:' , selected_fav_cuisine_id_list)
        print('aaaa' * 30)
        
        #料理情報をキー：カテゴリ、値：料理情報（selected_cuisines_dinnerなどに入れる値）として辞書に格納
        selected_fav_cuisine_dict = {}
        
        for cuisine_id in selected_fav_cuisine_id_list:
            fav_cuisine_info = Cuisine_info.query.filter_by(cuisine_id=cuisine_id).first()
            selected_fav_cuisine_dict[fav_cuisine_info.category] = fav_cuisine_info.cuisine_name
            
        #選択料理情報取得
        selected_cuisines_list = []
        for category_nm , cuisine_nm in selected_fav_cuisine_dict.items():
            #料理名から、対象の料理情報を取得
            fav_cuisine_info = list(filter(lambda x:x['cuisine_name'] == cuisine_nm , cuisine_list))[0]
            selected_cuisines_list.append(fav_cuisine_info)
            
        #ランチの場合
        if lunch_dinner_kbn == '1':
            #ランチ
            show_info_lunch = set_show_info(selected_cuisines_list , list_taisho_cuisine_cate_key_lunch , 30)
            
            #ディナー
            ###show_info_dinner = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_dinner , 30)
            
            #お気に入り画面用情報取得
            list_user_fav_info_all = get_list_fav_dict(9999)
            
        #ディナーの場合
        else:
            #ランチ
            ###show_info_lunch = set_show_info(cuisine_list , list_taisho_cuisine_cate_key_lunch , 30)
            
            #ディナー
            show_info_dinner = set_show_info(selected_cuisines_list , list_taisho_cuisine_cate_key_dinner , 30)
            
            #お気に入り画面用情報取得
            list_user_fav_info_all = get_list_fav_dict(9999)

        return render_template('omame1.html' 
                                , show_info_lunch = show_info_lunch
                                , show_info_dinner = show_info_dinner
                                , list_user_fav_info_all = list_user_fav_info_all
                                )

if __name__ == "__main__":
    app.run()